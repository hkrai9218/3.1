//declare your variables here


function setup() {
  createCanvas(400, 400);

  //add shapes to your variables here

}

function draw() {
  //color the background
  background('white');

  //start coding here

}
